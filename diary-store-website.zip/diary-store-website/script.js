const products = [
  {name:"The Everyday Journal",type:"journal",label:"Journal",price:349,color:"#b77d70",cover:"the everyday\njournal"},
  {name:"Sunday Planner",type:"planner",label:"Planner",price:429,color:"#8b967b",cover:"make it\nhappen"},
  {name:"Classic Notes",type:"classic",label:"Classic",price:299,color:"#78869a",cover:"little\nthoughts"},
  {name:"Bloom Diary",type:"journal",label:"Journal",price:399,color:"#c49a69",cover:"bloom\nwhere you are"},
  {name:"Daily Goals Planner",type:"planner",label:"Planner",price:459,color:"#a18caa",cover:"one day\nat a time"},
  {name:"Minimalist Diary",type:"classic",label:"Classic",price:329,color:"#77756d",cover:"less but\nbetter"},
  {name:"Dream Notes",type:"journal",label:"Journal",price:379,color:"#b77f91",cover:"dear\ndreams"},
  {name:"Weekly Planner",type:"planner",label:"Planner",price:449,color:"#7d9b9a",cover:"plan your\nweek"}
];
let cart = [];
const grid = document.getElementById("productGrid");
const count = document.getElementById("cartCount");
const toast = document.getElementById("toast");

function renderProducts(filter="all") {
  grid.innerHTML = "";
  products.filter(p => filter === "all" || p.type === filter).forEach((p) => {
    const card = document.createElement("article");
    card.className = "product-card";
    card.innerHTML = `
      <div class="product-art"><div class="diary-cover" style="background:${p.color}">${p.cover}</div></div>
      <div class="product-info">
        <h3>${p.name}</h3>
        <div class="product-meta"><span>${p.label}</span><span class="price">₹${p.price}</span></div>
        <button class="add-button" type="button">ADD TO CART</button>
      </div>`;
    card.querySelector("button").addEventListener("click", () => addToCart(p));
    grid.appendChild(card);
  });
}
function addToCart(product) {
  cart.push(product);
  count.textContent = cart.length;
  toast.textContent = `${product.name} added to your cart`;
  toast.classList.add("show");
  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
}
document.querySelectorAll(".filter").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelector(".filter.active").classList.remove("active");
    button.classList.add("active");
    renderProducts(button.dataset.filter);
  });
});
document.getElementById("cartButton").addEventListener("click", () => {
  if (!cart.length) { toast.textContent = "Your cart is empty."; }
  else {
    const total = cart.reduce((sum, item) => sum + item.price, 0);
    toast.textContent = `${cart.length} item(s) · Total ₹${total}`;
  }
  toast.classList.add("show");
  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => toast.classList.remove("show"), 2500);
});
renderProducts();
